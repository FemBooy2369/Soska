using System;
using System.Drawing;
using System.Windows.Forms;
using System.Media;

namespace WinFormsApp6
{
    public partial class Form1 : Form
    {
        private TrackBar slider;
        private Label lblVolume;
        private Button btnMute;
        private PictureBox gifBox;
        private Label statusLabel;
        private System.Windows.Forms.Timer soundTimer;   

        private bool isMuted = false;
        private int lastVolume = 70;

        public Form1()
        {
            InitializeComponent();
            SetupUI();
        }

        private void SetupUI()
        {
            this.Text = "Регулятор Громкости";
            this.Size = new Size(700, 620);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = Color.FromArgb(18, 18, 28);

            gifBox = new PictureBox
            {
                Location = new Point(200, 40),
                Size = new Size(280, 280),
                SizeMode = PictureBoxSizeMode.Zoom,
                BackColor = Color.Transparent
            };
            this.Controls.Add(gifBox);

            slider = new TrackBar
            {
                Location = new Point(80, 380),
                Size = new Size(520, 55),
                Minimum = 0,
                Maximum = 100,
                Value = 70,
                TickFrequency = 10,
                TickStyle = TickStyle.BottomRight
            };
            slider.ValueChanged += Slider_ValueChanged;
            this.Controls.Add(slider);

            lblVolume = new Label
            {
                Location = new Point(240, 340),
                Size = new Size(220, 40),
                Font = new Font("Segoe UI", 18, FontStyle.Bold),
                ForeColor = Color.Orange,
                TextAlign = ContentAlignment.MiddleCenter
            };
            this.Controls.Add(lblVolume);

            btnMute = new Button
            {
                Text = "🔇 Замутить",
                Location = new Point(280, 460),
                Size = new Size(140, 60),
                Font = new Font("Segoe UI", 13, FontStyle.Bold),
                BackColor = Color.FromArgb(220, 50, 50),
                ForeColor = Color.White
            };
            btnMute.Click += BtnMute_Click;
            this.Controls.Add(btnMute);

            statusLabel = new Label
            {
                Location = new Point(100, 540),
                Size = new Size(500, 35),
                Font = new Font("Segoe UI", 12),
                ForeColor = Color.LightGreen,
                TextAlign = ContentAlignment.MiddleCenter
            };
            this.Controls.Add(statusLabel);

            soundTimer = new System.Windows.Forms.Timer();
            soundTimer.Interval = 350;
            soundTimer.Tick += SoundTimer_Tick;
            soundTimer.Start();

            LoadGif();
            UpdateUI();
        }

        private void LoadGif()
        {
            try
            {     //Тут надо указать путь на вашу гифку
                gifBox.Image = Image.FromFile(@"D:\дрочилово\humstercombat.gif");
            }
            catch
            {
                statusLabel.Text = "GIF не найден";
            }
        }

        private void Slider_ValueChanged(object sender, EventArgs e)
        {
            if (isMuted) return;
            lastVolume = slider.Value;
            UpdateUI();
        }

        private void UpdateUI()
        {
            lblVolume.Text = $"Громкость: {slider.Value}%";

            if (slider.Value == 0) lblVolume.ForeColor = Color.Gray;
            else if (slider.Value <= 30) lblVolume.ForeColor = Color.Cyan;
            else if (slider.Value <= 60) lblVolume.ForeColor = Color.Lime;
            else if (slider.Value <= 85) lblVolume.ForeColor = Color.Orange;
            else lblVolume.ForeColor = Color.Red;
        }

        private void SoundTimer_Tick(object sender, EventArgs e)
        {
            if (isMuted || slider.Value < 5) return;

            int frequency = 650 + (slider.Value * 13);
            try
            {
                Console.Beep(frequency, 90);
            }
            catch { }
        }

        private void BtnMute_Click(object sender, EventArgs e)
        {
            isMuted = !isMuted;

            if (isMuted)
            {
                btnMute.Text = "🔊 Включить";
                btnMute.BackColor = Color.FromArgb(0, 170, 0);
                statusLabel.Text = "🔇 Звук замучен";
                statusLabel.ForeColor = Color.OrangeRed;
            }
            else
            {
                btnMute.Text = "🔇 Замутить";
                btnMute.BackColor = Color.FromArgb(220, 50, 50);
                statusLabel.Text = "Звук включён";
                statusLabel.ForeColor = Color.LightGreen;
                slider.Value = lastVolume;
            }
        }
    }
}