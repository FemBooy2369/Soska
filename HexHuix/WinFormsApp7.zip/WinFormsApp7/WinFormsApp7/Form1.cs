using System;
using System.Drawing;
using System.Windows.Forms;

namespace ColorPickerApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "Тест выбора цвета";
            this.Size = new Size(520, 440);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.Font = new Font("Segoe UI", 10);

            Button btnOpenPicker = new Button
            {
                Text = "Открыть выбор цвета",
                Location = new Point(160, 80),
                Size = new Size(220, 55),
                Font = new Font("Segoe UI", 12, FontStyle.Bold)
            };
            btnOpenPicker.Click += BtnOpenPicker_Click;

            Panel previewPanel = new Panel
            {
                Name = "previewPanel",
                Location = new Point(130, 190),
                Size = new Size(260, 150),
                BorderStyle = BorderStyle.FixedSingle,
                BackColor = Color.White
            };

            Label lblInfo = new Label
            {
                Text = "Нажмите кнопку для выбора цвета",
                Location = new Point(140, 40),
                Size = new Size(320, 30),
                Font = new Font("Segoe UI", 11)
            };

            this.Controls.Add(btnOpenPicker);
            this.Controls.Add(previewPanel);
            this.Controls.Add(lblInfo);
        }

        private void BtnOpenPicker_Click(object sender, EventArgs e)
        {
            using (ColorPickerForm picker = new ColorPickerForm())
            {
                if (picker.ShowDialog() == DialogResult.OK)
                {
                    if (this.Controls["previewPanel"] is Panel previewPanel)
                    {
                        previewPanel.BackColor = picker.SelectedColor;
                    }
                }
            }
        }
    }

    public class ColorPickerForm : Form
    {
        private TrackBar trackR, trackG, trackB, trackBrightness;
        private Label lblRValue, lblGValue, lblBValue, lblBrightValue;
        private TextBox txtHex;
        private Panel colorPreview;
        private Button btnOK, btnCancel;

        public Color SelectedColor { get; private set; } = Color.White;

        public ColorPickerForm()
        {
            this.Text = "Выбор цвета";
            this.Size = new Size(460, 410);
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.StartPosition = FormStartPosition.CenterScreen;
            this.MaximizeBox = false;

            InitializeColorPicker();
            UpdateColor();
        }

        private void InitializeColorPicker()
        {
            // R
            new Label { Text = "R:", Location = new Point(20, 20), Size = new Size(30, 20) }.Parent = this;
            trackR = new TrackBar { Minimum = 0, Maximum = 255, Value = 255, Location = new Point(60, 15), Size = new Size(220, 45), Parent = this };
            trackR.Scroll += TrackBar_Scroll;
            lblRValue = new Label { Text = "255", Location = new Point(290, 22), Size = new Size(45, 20), Parent = this };

            // G
            new Label { Text = "G:", Location = new Point(20, 70), Size = new Size(30, 20) }.Parent = this;
            trackG = new TrackBar { Minimum = 0, Maximum = 255, Value = 255, Location = new Point(60, 65), Size = new Size(220, 45), Parent = this };
            trackG.Scroll += TrackBar_Scroll;
            lblGValue = new Label { Text = "255", Location = new Point(290, 72), Size = new Size(45, 20), Parent = this };

            // B
            new Label { Text = "B:", Location = new Point(20, 120), Size = new Size(30, 20) }.Parent = this;
            trackB = new TrackBar { Minimum = 0, Maximum = 255, Value = 255, Location = new Point(60, 115), Size = new Size(220, 45), Parent = this };
            trackB.Scroll += TrackBar_Scroll;
            lblBValue = new Label { Text = "255", Location = new Point(290, 122), Size = new Size(45, 20), Parent = this };

            // Яркость
            new Label { Text = "Яркость:", Location = new Point(20, 170), Size = new Size(60, 20) }.Parent = this;
            trackBrightness = new TrackBar { Minimum = 0, Maximum = 100, Value = 100, Location = new Point(90, 165), Size = new Size(220, 45), Parent = this };
            trackBrightness.Scroll += TrackBar_Scroll;
            lblBrightValue = new Label { Text = "100%", Location = new Point(320, 170), Size = new Size(50, 20), Parent = this };

            // HEX
            new Label { Text = "HEX:", Location = new Point(20, 225), Size = new Size(40, 20) }.Parent = this;
            txtHex = new TextBox { Location = new Point(70, 222), Size = new Size(110, 25), Text = "#FFFFFF", MaxLength = 7, Parent = this };
            txtHex.TextChanged += TxtHex_TextChanged;

            // Предпросмотр
            colorPreview = new Panel
            {
                Location = new Point(320, 25),
                Size = new Size(110, 110),
                BorderStyle = BorderStyle.FixedSingle,
                Parent = this
            };

            // Кнопки
            btnOK = new Button { Text = "OK", Location = new Point(240, 300), Size = new Size(90, 40), Parent = this };
            btnOK.Click += BtnOK_Click;

            btnCancel = new Button { Text = "Отмена", Location = new Point(340, 300), Size = new Size(90, 40), Parent = this };
            btnCancel.Click += (s, e) => this.DialogResult = DialogResult.Cancel;
        }

        private void TrackBar_Scroll(object sender, EventArgs e)
        {
            lblRValue.Text = trackR.Value.ToString();
            lblGValue.Text = trackG.Value.ToString();
            lblBValue.Text = trackB.Value.ToString();
            lblBrightValue.Text = trackBrightness.Value + "%";

            UpdateColor();
        }

        private void TxtHex_TextChanged(object sender, EventArgs e)
        {
            if (txtHex.Text.Length == 7 && txtHex.Text.StartsWith("#"))
            {
                try
                {
                    Color c = ColorTranslator.FromHtml(txtHex.Text);
                    trackR.Value = c.R;
                    trackG.Value = c.G;
                    trackB.Value = c.B;
                    lblRValue.Text = c.R.ToString();
                    lblGValue.Text = c.G.ToString();
                    lblBValue.Text = c.B.ToString();
                    UpdateColor(false);
                }
                catch { }
            }
        }

        private void UpdateColor(bool updateHex = true)
        {
            int r = trackR.Value;
            int g = trackG.Value;
            int b = trackB.Value;

            float brightness = trackBrightness.Value / 100f;

            r = (int)Math.Round(r * brightness);
            g = (int)Math.Round(g * brightness);
            b = (int)Math.Round(b * brightness);

            r = Math.Clamp(r, 0, 255);
            g = Math.Clamp(g, 0, 255);
            b = Math.Clamp(b, 0, 255);

            Color finalColor = Color.FromArgb(255, r, g, b);
            colorPreview.BackColor = finalColor;
            SelectedColor = finalColor;

            if (updateHex)
                txtHex.Text = "#" + finalColor.R.ToString("X2") + finalColor.G.ToString("X2") + finalColor.B.ToString("X2");
        }

        private void BtnOK_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.OK;
        }
    }
}